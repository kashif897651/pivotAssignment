# pivotAssignment
